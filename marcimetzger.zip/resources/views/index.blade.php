<!DOCTYPE html>
<html>
    <head>
        <title>Marci Metzger</title>


    </head>
    <body>
        <div id="root"></div>
        @viteReactRefresh
        @vite('resources/js/app.ts')

    </body>



</html>
