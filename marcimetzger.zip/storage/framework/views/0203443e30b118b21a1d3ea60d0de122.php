<!DOCTYPE html>
<html>
    <head>
        <title>Marci Metzger</title>


    </head>
    <body>
        <div id="root"></div>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.ts'); ?>

    </body>



</html>
<?php /**PATH C:\xampp\htdocs\marcimetzger\resources\views/index.blade.php ENDPATH**/ ?>